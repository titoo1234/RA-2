﻿using System;
using Humanizer;
namespace Primer2
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vnesi drugo številko:");
            int prvo = int.Parse(Console.ReadLine());
            char znak = 'a';
            string bla = "a";
            string t = znak.ToString();
            string niz = "" + znak;
            Console.WriteLine(znak);
            Console.WriteLine(bla);
            Console.WriteLine(znak + bla);
            Console.WriteLine(bla + znak);

            int a = 7;
            Console.WriteLine("Hello World!");
            (int, string)[] tab = new (int, string)[10];
            tab[0] = (6, "bla");
            Console.WriteLine(tab[0]);
            Console.WriteLine(tab[0].Item1);

            int x = 123;
            Console.WriteLine(x.ToRoman());
            Console.WriteLine(x.ToMetric());
            int neki = Max(1, 2);
            Console.WriteLine(neki);







        }
        /// <summary>
        /// vrača primerno celo število
        /// </summary>
        /// <param name="a">Prvi podatek..</param>
        /// <param name="b">Drugi podatek</param> 
        /// <returns></returns>
        public static int Max(int a, int b)
        {
            return a;
        }

        /// <summary>
        /// V tabeli zamenja prvi in najmanjši element
        /// </summary>
        /// <param name="tab">tabela celih števil</param>
        public static void NajmanjsiNazacetek(int[] tab)
        {
            if (tab.Length == 0)
            {
                throw new Exception("Tabela ima dolžino 0");
            }
            int kje = 0;
            int naj = tab[0];
            for (int i = 1; i < tab.Length; i++)
            {
                if(tab[i] < naj)
                {
                    naj = tab[i];
                    kje = i;
                }    
            }
            // zamenjaj 1. in kje-tega
            int prvi = tab[0];
            tab[0] = tab[kje];
            tab[kje] = prvi;



        }
    }
}
