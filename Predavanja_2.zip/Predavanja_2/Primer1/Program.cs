﻿using System;

namespace Primer1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vnesi niz");
            string vnos = Console.ReadLine();
            string obrnjeni = "";
            int dolzina = vnos.Length;
            int kje = 0;
            while (kje < dolzina)
            {
                obrnjeni = vnos[kje] + obrnjeni;
                kje++;
            }

            Console.WriteLine($"niz {vnos} je obrnjen {obrnjeni}");
        }
    }
}
