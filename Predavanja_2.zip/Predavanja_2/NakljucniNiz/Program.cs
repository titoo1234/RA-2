﻿using System;

namespace NakljucniNiz
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vnesi niz nakov:");
            string vnos = Console.ReadLine();
            Console.WriteLine("Vnesi dolžino naključnega niza");
            int dolzina = int.Parse(Console.ReadLine());
            if (vnos.Length < dolzina)
            {
                Console.WriteLine("V nizu ni dovolj različnih znakov.");
            }
            else
            {
                Random random = new Random();
                string niz = "";
                for (int i = 0; i< dolzina; i++)
                {
                    int index = random.Next(0, dolzina - 1);
                    niz += vnos[index];


                }
                Console.WriteLine(niz);

            }

        }
    }
}
