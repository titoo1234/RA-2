﻿using System;
using System.Linq;
namespace PitonNaObisku
{
    class Program
    {
        static void Main(string[] args)
        {
            string niz = prestej("le", "Danes je lep dan");
            string niz2 = prestej("kr neki", "danes je sončno");
            Console.WriteLine(niz2);
            Console.WriteLine("Hello World!");
        }
        public static string prestej(string s, string t)
        {
            int[] tab = new int[t.Length];
            for (int i = 0;i< t.Length; i++)
            {
                char znak = t[i];
                tab[i] = PrestejZnake(s, znak);
            }
            int m = tab.Max();
            char[] u = new char[t.Length];
            for (int i = 0; i < t.Length; i++)
            {
                if (tab[i] == m)
                {
                    u[i] = t[i];
                }
                
            }
            string niz = "";
            for (int i = 0; i < u.Length; i++)
            {
                niz += u[i];
            }
            return niz;



        }

        public static int PrestejZnake(string s, char z)
        {
            int koliko = 0;
            for (int i = 0; i < s.Length; i++)
            {if(s[i] == z) { koliko += 1; }


            }
            return koliko;


        }
        }
}

