﻿using System;

namespace Vsote
{
    public static class Extensions
    {
        public static T[] SubArray<T>(this T[] array, int offset, int length)
        {
            T[] result = new T[length];
            Array.Copy(array, offset, result, 0, length);
            return result;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            int[] list = { 1, 2, 3 };
            int[] pod = list.SubArray(1,2);

        }
        public static int[] DelneVsote(int[] seznam, int k)
        {
            int[] tab = new int[seznam.Length - k];
            for (int i = 1; i < seznam.Length - k;i++)
            { 
                int vsota = 0;
                int[] nova = seznam.SubArray(i, k);
                for(int j = 1; i < nova.Length; j++)
                {
                    vsota += nova[j];
                }
                tab[i] = vsota;
            }
            return tab;
        }





    }
}
