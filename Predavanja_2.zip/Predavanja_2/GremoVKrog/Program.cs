﻿using System;

namespace GremoVKrog
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vnesi elemente tabele:");
            string stevila = Console.ReadLine();
            string[] tab_stevil = stevila.Split(' ');
            Console.WriteLine("Vnesi pomik:");
            int pomik = int.Parse(Console.ReadLine());
            for (int i = 0;i < pomik; i++)
            {
                string prvo = tab_stevil[0];
                for(int j = 0;j< tab_stevil.Length-1; j++)
                {
                    tab_stevil[j] = tab_stevil[j + 1];
                }
                tab_stevil[tab_stevil.Length-1] = prvo;
            }
            Console.WriteLine();
            Izpis_tabele(tab_stevil);

        }

        public static void Izpis_tabele(string[] tab)
        {
            foreach (string s in tab)
            {
                Console.Write(s + " ");
            }
        }
    }
}
