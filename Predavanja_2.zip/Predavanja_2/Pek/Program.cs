﻿using System;

namespace Pek
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi predpisano tezo hlebca: "); double tezaPredpis = double.Parse(Console.ReadLine()); Console.Write("Vnesi stevilo hlebcev v pekarni: ");
            int steviloHlebcev = int.Parse(Console.ReadLine());
            int stevecNapacnih = 0;
            double minTeza = tezaPredpis * 0.8; double maxTeza = tezaPredpis * 1.2; for (int i = 1; i < steviloHlebcev; i++)
            {
                Console.Write("Vnesi tezo: " + i + ". hlebca ");
                double dejanskaTeza = double.Parse(Console.ReadLine());
                //Če je teža hlebca 20% manjša od predpisa, ga štej med napačne hlebce
                stevecNapacnih = NewMethod1(stevecNapacnih, minTeza, maxTeza, dejanskaTeza);
            }
            //računamo ali bo pek pil vodo
            NewMethod(steviloHlebcev, stevecNapacnih);
        }

        private static int NewMethod1(int stevecNapacnih, double minTeza, double maxTeza, double dejanskaTeza)
        {
            if ((dejanskaTeza < minTeza) || (dejanskaTeza > maxTeza)) stevecNapacnih++;
            return stevecNapacnih;
        }

        private static void NewMethod(int steviloHlebcev, int stevecNapacnih)
        {
            if (stevecNapacnih > steviloHlebcev * 0.15) Console.WriteLine("Peka v vodo takoj!!!!"); else Console.WriteLine("Pek ima dobro mero");
        }
    }
}
