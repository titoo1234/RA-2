﻿using System;

namespace HisneStevilke
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vnesi prvo številko:");

            int prvo = int.Parse(Console.ReadLine());
            Console.WriteLine("Vnesi drugo številko:");

            int drugo = int.Parse(Console.ReadLine());
            int[] tab = new int[10];
            for (int i = prvo;i < drugo + 1; i++)
            {
                string st = i.ToString();
                
                foreach (char c in st)
                {

                    tab[int.Parse(c.ToString())] += 1; 
                }

            }
            int k = 0;
            foreach (int c in tab)
            {

                Console.WriteLine(k +" "+ c);
                k++;
            }

        }
    }
}
